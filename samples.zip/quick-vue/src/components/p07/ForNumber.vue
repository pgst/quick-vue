<script setup>
</script>

<template>
  <span v-for="i in 5" v-bind:key="i">
    {{ i }}　</span>
</template>

<style scoped>
</style>
