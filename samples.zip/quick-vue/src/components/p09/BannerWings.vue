<script setup>
</script>

<template>
  <div class="banner">
    <h3>WINGSプロジェクトについて</h3>
    <p>WINGSプロジェクトは、ライター山田祥寛が代表を務める執筆コミュニティです。</p>
    <p>2005年5月、「有限会社 WINGSプロジェクト」として法人化を果たしたのを機に、ますます質の高い情報を読者の方々にお届けしてまいります。</p>
  </div>
</template>

<style scoped>
</style>
