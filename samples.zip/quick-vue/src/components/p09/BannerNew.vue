<script setup>
</script>

<template>
  <div class="banner">
    <h3>新刊紹介</h3>
    <p>これからはじめるVue.js 3実践入門  </p>
    <img src="https://wings.msn.to/books/978-4-8156-1336-5/978-4-8156-1336-5.jpg" />
  </div>
</template>

<style scoped>
</style>
