<script setup>
</script>

<template>
  <div class="jumbotron">
    <p>こんにちは、Teleport!!</p>
    <Teleport to="#result">
      Teleportからテレポートされたテキスト
    </Teleport>
    <div>こんにちは、Teleport!!</div>
  </div>
  <hr />  
</template>

<style scoped>
</style>
