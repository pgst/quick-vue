<script setup>
</script>

<template>
  <div class="sub">
    <h5>サブビュー</h5>
    <img src="https://wings.msn.to/image/wings.jpg" />
  </div>
</template>

<style scoped>
</style>