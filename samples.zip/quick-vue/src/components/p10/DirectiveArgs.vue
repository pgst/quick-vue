<script setup>
import { ref } from 'vue'
const color = ref('Red')
</script>

<template>
  <p>JavaScriptフレームワークの代表として、Angular、React、<span v-arged-highlight:text="color">Vue.js</span>などが挙げられます。</p>
</template>

<style scoped>
</style>
