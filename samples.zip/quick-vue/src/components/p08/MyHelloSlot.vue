<script setup>
</script>

<template>
  <div>こんにちは、<slot>権兵衛</slot>さん！</div>
</template>

<style scoped>
</style>
