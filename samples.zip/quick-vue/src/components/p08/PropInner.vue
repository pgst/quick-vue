<script setup>
import MyCounter from './MyCounter.vue'
</script>

<template>
  <MyCounter v-bind:init="1" />
</template>

<style scoped>
</style>
