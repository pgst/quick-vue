<script setup>
import MyHelloAttr from './MyHelloAttr.vue'
</script>

<template>
  <MyHelloAttr name="鈴木次郎" id="hello" class="hoge" />
</template>

<style scoped>
</style>
