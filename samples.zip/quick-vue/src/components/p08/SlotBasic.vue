<script setup>
import MyHelloSlot from './MyHelloSlot.vue'
</script>

<template>
  <MyHelloSlot>鈴木次郎</MyHelloSlot>
</template>

<style scoped>
</style>
